/**
 * Dept Class
 * @param {Object} deptno
 * @param {Object} dname
 * @param {Object} dloc
 */
function Dept(deptno, dname, dloc){
	this.deptno=deptno;
	this.dname=dname;
	this.dloc=dloc;
}

module.exports=Dept;